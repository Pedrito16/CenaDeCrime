using UnityEngine;

public class MenuCameraFollow : MonoBehaviour
{
    [Header("Refer�ncias")]
    public Transform cameraTransform;

    [Header("Movimento")]
    public float maxRotationX = 5f;
    public float maxRotationY = 8f;

    [Header("Suaviza��o")]
    public float smoothSpeed = 5f;

    private Quaternion initialRotation;

    void Start()
    {
        if (cameraTransform == null)
            cameraTransform = Camera.main.transform;

        initialRotation = cameraTransform.localRotation;

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    void Update()
    {
        // Posi��o do mouse normalizada (-1 at� 1)
        float mouseX = (Input.mousePosition.x / Screen.width) * 2f - 1f;
        float mouseY = (Input.mousePosition.y / Screen.height) * 2f - 1f;

        // Rota��o alvo
        float rotY = mouseX * maxRotationY;
        float rotX = -mouseY * maxRotationX;

        Quaternion targetRotation =
            initialRotation * Quaternion.Euler(rotX, rotY, 0);

        // Suaviza��o
        cameraTransform.localRotation = Quaternion.Lerp(
            cameraTransform.localRotation,
            targetRotation,
            smoothSpeed * Time.deltaTime
        );
    }
}