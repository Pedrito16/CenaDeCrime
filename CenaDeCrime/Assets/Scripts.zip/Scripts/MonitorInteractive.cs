using UnityEngine;
using UnityEngine.Playables;

public class MonitorInteractive : MonoBehaviour
{
    [Header("Tela do monitor")]
    public MeshRenderer monitorRenderer;
    [SerializeField] GameObject textObject;

    [Header("Materiais")]
    public Material monitorLigado;
    public Material monitorDesligado;

    [Header("Luzes desse monitor")]
    public Light[] monitorLights;

    [Header("Timeline")]
    public PlayableDirector timeline;

    [Header("Script da c�mera do player")]
    public MonoBehaviour cameraController;

    [SerializeField] bool mouseEmCima = false;
    public int buttonIndex;
    public bool isReversible = false;
    private bool estaNaTimeline = false;

    void Start()
    {
        DesligarMonitor();
    }

    void Update()
    {
        // Clique esquerdo
        if (mouseEmCima && Input.GetMouseButtonDown(0))
        {
            if (timeline != null)
            {
                // Desativa c�mera do player
                if (cameraController != null)
                {
                    cameraController.enabled = false;
                }

                // Toca Timeline
                timeline.Play();
                MenuController.instance.OnClickButton(buttonIndex);
                estaNaTimeline = true;
            }
        }

        // ESC para voltar
        if (estaNaTimeline && Input.GetKeyDown(KeyCode.Escape) && isReversible)
        {
            SairDaTimeline();
            MenuController.instance.ActivateButtons();
        }
    }

    void SairDaTimeline()
    {
        if (timeline != null)
        {
            // Volta Timeline pro in�cio
            timeline.time = 0;

            // Atualiza imediatamente
            timeline.Evaluate();

            // Para Timeline
            timeline.Stop();
        }

        // Reativa c�mera do player
        if (cameraController != null)
        {
            cameraController.enabled = true;
        }

        estaNaTimeline = false;
    }

    void OnMouseEnter()
    {
        mouseEmCima = true;
        LigarMonitor();
    }

    void OnMouseExit()
    {
        mouseEmCima = false;
        DesligarMonitor();
    }

    void LigarMonitor()
    {
        if (monitorRenderer != null)
        {
            textObject.SetActive(true);
            monitorRenderer.material = monitorLigado;
        }

        foreach (Light luz in monitorLights)
        {
            if (luz != null)
                luz.enabled = true;
        }
    }

    void DesligarMonitor()
    {
        if (monitorRenderer != null)
        {
            monitorRenderer.material = monitorDesligado;
            textObject.SetActive(false);
        }

        foreach (Light luz in monitorLights)
        {
            if (luz != null)
                luz.enabled = false;
        }
    }
}